import React from 'react';

const CategoriesNav = ({ categories, activeCategory, onSelectCategory }) => {
  return (
    <nav className="categories-nav">
      {categories.map((cat) => (
        <button
          key={cat}
          className={`nav-button ${activeCategory === cat ? 'active' : ''}`}
          onClick={() => onSelectCategory(cat)}
        >
          {cat}
        </button>
      ))}
    </nav>
  );
};

export default CategoriesNav;