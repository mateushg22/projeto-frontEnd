import { useState } from "react";

export function ProductCard({ name, idade, category, image, estilo }) {
    const [active, setActive] = useState(false);

    return (
        <div className="product-card">
            <img src={image} alt={name} width={150} />
        
            <div>
                <h1>{name}</h1>
                <p><strong>Idade:</strong> {idade} anos</p>
                <p><strong>Estilo:</strong> {estilo}</p>
                <div><small>Categoria: {category}</small></div>
                </div>
                    <button 
                        className={`card-buttons ${active ? 'active':''}`}
                        onClick={() => setActive(!active)}
                    > 
                        Favorito 
                    </button>
                <div>
            
            </div>

        </div>
    );
}